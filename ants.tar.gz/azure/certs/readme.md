
Empty directory used to create certs during deployment. 