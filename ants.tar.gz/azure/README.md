# Phoenix DevOps pipeline to create application/AKS services owned by limited rights service principal

## Task list
    Task 1 'Get Certificate from KeyVault'
        Using service connector pull devops service principal creds from devops keyvault. 

    Task 2 'Terraform Infra apply'
        Using devop's service principal create resource group, keyvault and application service principal

    Task 3 'Grant Storage Role to App SP'
        Using devops service principal grant application service principal permission to Azure storage for tfstate files. 

    Task 4 'Encrypt App pfx file'
        Encypt the cert private key component of application pfx file and store in ./certs directory for terraform connection

    Task 5 'Terraform App/AKS apply' 
        Using application service principal create application services and/or AKS cluster. 

    Task 6 'Terraform AppRole apply' 
        Using devops service principal grant roles to application services and/or AKS cluster.  
