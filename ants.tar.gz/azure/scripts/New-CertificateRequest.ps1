Param ( 
    [Parameter(Mandatory = $true, HelpMessage = "Please enter the subject beginning with CN=")]
    [ValidatePattern("CN=")]
    [string]$subject,
    [Parameter(Mandatory = $true, HelpMessage = "Please enter the Friendly name")]
    [string]$Friendlyname,
    [Parameter(Mandatory = $false, HelpMessage = "Please enter the SAN domains as a comma separated list")]
    [array]$SANs,
    [Parameter(Mandatory = $false, HelpMessage = "Please enter the Cert Export Password")]
    [string]$Password, 
    [Parameter(Mandatory = $false, HelpMessage = "Please enter Directory Path for export certs")]
    [string]$DirectoryPath
) 

function New-CertificateRequest {
    param (
        [Parameter(Mandatory = $true, HelpMessage = "Please enter the subject beginning with CN=")]
        [ValidatePattern("CN=")]
        [string]$subject,
		[Parameter(Mandatory = $true, HelpMessage = "Please enter the Friendly name")]
        [string]$Friendlyname,
		[Parameter(Mandatory = $false, HelpMessage = "Please enter the SAN domains as a comma separated list")]
        [array]$SANs,
		[Parameter(Mandatory = $false, HelpMessage = "Please enter the Cert Export Passowrd")]
        [string]$Password,
        [Parameter(Mandatory = $false, HelpMessage = "Please enter Directory Path for export certs")]
        [string]$DirectoryPath, 
        [Parameter(Mandatory = $false, HelpMessage = "Please enter the Online Certificate Authority")]
        [string]$OnlineCA="stm-certsub-01.odysseyre.net\odysseyre-STM-CERTSUB-01-CA",
        [Parameter(Mandatory = $false, HelpMessage = "Please enter the Online Certificate Authority")]
        [string]$CATemplate = "OdysseyGroup-Web Server plus Client Authentication-2016"
    )

    $CertificateINI = "$DirectoryPath/$friendlyname.ini"
    $CertificateREQ = "$DirectoryPath/$friendlyname.req"
    $CertificateRSP = "$DirectoryPath/$friendlyname.rsp"
    $CertificateCER = "$DirectoryPath/$friendlyname.cer"
	$CertificateRes = "$DirectoryPath/$friendlyname.res"
	$CertificatePfx = "$DirectoryPath/$friendlyname.pfx"
    $CertificateCrt = "$DirectoryPath/$friendlyname.crt"
    $CertificateKey = "$DirectoryPath/$friendlyname.key"

    ### INI file generation
    new-item -type file $CertificateINI -force
    add-content $CertificateINI '[NewRequest]'
    $temp = 'Subject = "' + $subject + '"'
    add-content $CertificateINI $temp
	$temp = 'FriendlyName = "' + $friendlyname + '"'
	add-content $CertificateINI $temp
    add-content $CertificateINI 'Exportable = "True"'
    add-content $CertificateINI 'KeyLength = "2048"'
    add-content $CertificateINI 'RequestType = "PKCS10"'
    add-content $CertificateINI 'ProviderName = "Microsoft RSA SChannel Cryptographic Provider"'
    add-content $CertificateINI 'KeySpec = "AT_KEYEXCHANGE"'
	add-content $CertificateINI ''
    add-content $CertificateINI '[RequestAttributes]'
    add-content $CertificateINI 'CertificateTemplate = "OdysseyGroup-WebServerplusClientAuthentication-2016"'
	add-content $CertificateINI ''
	add-content $CertificateINI '[Extensions]'
    add-content $CertificateINI '2.5.29.17 = "{text}"'
    foreach ($SAN in $SANs) {
        $temp = '_continue_ = "dns=' + $SAN + '&"'
        add-content $CertificateINI $temp
	}
	foreach ($SAN in $SANs) {
        $temp = '_continue_ = "url=https://' + $SAN + '&"'
        add-content $CertificateINI $temp
	}

    ### Certificate request generation
    if (test-path $CertificateREQ) { del $CertificateREQ }
    certreq -new -machine $CertificateINI $CertificateREQ

    ### Online certificate request and import
    if ($OnlineCA) {
        if (test-path $CertificateCER) { del $CertificateCER }
        if (test-path $CertificateRSP) { del $CertificateRSP }
        certreq -submit -config $OnlineCA $CertificateREQ $CertificateCER
        certreq -accept $CertificateCER > $CertificateRes
        type $CertificateRes
		$thumbprint=(type $CertificateRes | sls Thumbprint).ToString().Replace(' ','').Split(':')[1]
        write-host $thumbprint
		$mypwd = ConvertTo-SecureString -String $Password -Force -AsPlainText
		get-ChildItem Cert:\LocalMachine\my\$thumbprint | Export-PfxCertificate -FilePath $CertificatePfx -Password $mypwd
		openssl pkcs12 -in $CertificatePfx -nocerts -out $CertificateKey -passin pass:$password -passout pass:$password
		openssl pkcs12 -in $CertificatePfx -nokeys  -out $CertificateCrt -passin pass:
		openssl rsa -in $CertificateKey -out "$CertificateKey.tmp" -passin pass:$password
		Remove-Item $CertificateKey 
		Copy-Item -Path "$CertificateKey.tmp" -Destination $CertificateKey
        Remove-Item "$CertificateKey.tmp"
    }		
} 

New-CertificateRequest -subject $subject -SANs $SANs -Friendlyname $Friendlyname -Password $Password -DirectoryPath $DirectoryPath
