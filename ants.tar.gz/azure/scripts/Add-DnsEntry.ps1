param( 
    [Parameter(Mandatory = $true)][string]$hostname,
    [Parameter(Mandatory = $true)][string]$dnszone,
    [Parameter(Mandatory = $true)][string]$ipaddress, 
    [Parameter(Mandatory = $true)][string]$dnsserver="dc2.odysseyre.net"
)

$hostname = $hostname + '.' + $dnszone
$tmp = $dnszone.Split(".")
if ( $tmp.count -eq 3 ) { 
    $dnszone = $tmp[1] + '.' + $tmp[2]
}

$ErrorActionPreferenceSaved = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
if ( $hostname ) { 
    $dnsname = Resolve-DnsName -Server $dnsserver $hostname
    if ( $dnsname ) {
        if ( $dnsname.IPAddress -ne $ipaddress) {
            return $dnsname.IPAddress
        }
        return $dnsname.IPAddress
    }
}

$hostname+='.'
$ErrorActionPreference = $ErrorActionPreferenceSaved
Add-DnsServerResourceRecordA -ComputerName $dnsserver -ZoneName $dnszone -Name $hostname -AllowUpdateAny -IPv4Address $ipaddress #-CreatePtr
if ( $? -eq $True) { return $ipaddress } 
return $ipaddress