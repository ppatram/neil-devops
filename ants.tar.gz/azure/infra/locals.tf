locals {  
  ecosystem_name    = format("phoenix-%s", var.ecosystemId)
  subscription_id   = "3e56c6ff-0d38-4f6a-9d6e-2c40efe46126"
  tenant_id         = "885e124e-4dc7-41ed-a268-3e401a62cead"

  tags = {
    Environment  = "DEV"
    Company      = "OdysseyRe"
    Application  = "Phoenix"
    Organization = "OdysseyGroup"
    AppFamily    = "Phoenix"
    Expiration = formatdate("YYYY-MM-DD", timeadd(timestamp(), "72h"))
  }
}
