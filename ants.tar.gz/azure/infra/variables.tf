variable "ecosystemId" {
  description = "Unique key for the instance of the environment"
  type        = string
}
