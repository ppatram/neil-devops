terraform {
  backend "azurerm" {
    resource_group_name  = "AZE-ODYHDC-OG-IT-DEVOPS-RG"
    storage_account_name = "azeodyhdcogitdevops"
    subscription_id      = "3e56c6ff-0d38-4f6a-9d6e-2c40efe46126"
    tenant_id            = "885e124e-4dc7-41ed-a268-3e401a62cead"
    container_name       = "phoenix-tfstates"
  }
}