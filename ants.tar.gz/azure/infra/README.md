# Phoenix Infrastructure Terraform
Creates a new resource group and grants owner permission to the service principal

