data "azurerm_client_config" "current" {
}

data "azuread_group" "k8s-cluster-admin" {
  display_name     = "Azure - K8S - OG - Phoenix Dev ClusterAdmin"
  security_enabled = true
}

resource "azurerm_resource_group" "app" {
  name     = local.ecosystem_name
  location = "eastus"
  tags     = local.tags
  lifecycle {
    ignore_changes = [tags["CreatedOnDate"]]
  }
}

resource "azurerm_role_assignment" "devops_owner" {
  scope                = azurerm_resource_group.app.id
  role_definition_name = "Owner"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "AKS_RBAC_Cluster_Admin" {
  scope                = azurerm_resource_group.app.id
  role_definition_name = "Owner"
  principal_id         = data.azuread_group.k8s-cluster-admin.object_id
}

output "rg" {
  value = azurerm_resource_group.app.name
}

output "ecosystem_name" {
  value = local.ecosystem_name
}