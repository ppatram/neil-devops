variable "subnet_name" {
  type    = string
  default = ""
}

variable "vnet_name" {
  type    = string
  default = ""
}

variable "vnet_rg" {
  type    = string
  default = ""
}

variable "subnet_service_endpoints" {
  type    = list(any)
  default = []
}

variable "private_endpoint_network_policies" {
  type    = string
  default = "Disabled"
}

variable "tags" {
  type = map(any)
}

variable "index" {
  type    = number
  default = 0
}