locals {
  vnet_address_space = format("%s.%s", split(".", one(data.azurerm_virtual_network.vnet.address_space))[0], split(".", one(data.azurerm_virtual_network.vnet.address_space))[1])
  possible_subnet    = [for i in range(120, 254) : format("%s.%s.0", local.vnet_address_space, i)]
  subnet_exists      = contains(tolist(data.azurerm_virtual_network.vnet.subnets), var.vnet_name)
  existing_subnets   = [for s in data.azurerm_subnet.existing_subnets.*.address_prefixes : split("/", tostring(s[0]))[0] if split(".", split("/", tostring(s[0]))[0])[3] == "0"]
  address_prefixes   = format("%s/24", flatten(setsubtract(local.possible_subnet, local.existing_subnets))[var.index])
}

data "azurerm_virtual_network" "vnet" {
  name                = var.vnet_name
  resource_group_name = var.vnet_rg
}

data "azurerm_subnet" "existing_subnets" {
  name                 = data.azurerm_virtual_network.vnet.subnets[count.index]
  virtual_network_name = data.azurerm_virtual_network.vnet.name
  resource_group_name  = data.azurerm_virtual_network.vnet.resource_group_name
  count                = length(data.azurerm_virtual_network.vnet.subnets)
}

data "azurerm_subnet" "subnet" {
  count                = local.subnet_exists ? 1 : 0
  name                 = var.subnet_name
  virtual_network_name = data.azurerm_virtual_network.vnet.name
  resource_group_name  = data.azurerm_virtual_network.vnet.resource_group_name
}

resource "azurerm_subnet" "subnet" {
  count                                          = local.subnet_exists ? 0 : 1
  name                                           = var.subnet_name
  address_prefixes                               = [local.address_prefixes]
  private_endpoint_network_policies              = var.private_endpoint_network_policies
  virtual_network_name                           = data.azurerm_virtual_network.vnet.name
  resource_group_name                            = data.azurerm_virtual_network.vnet.resource_group_name
  service_endpoints                              = var.subnet_service_endpoints
  lifecycle {
    ignore_changes = [address_prefixes]
  }
}

output "subnet_id" {
  value = local.subnet_exists ? data.azurerm_subnet.subnet.0.id : azurerm_subnet.subnet.0.id
}

output "subnet_cidr" {
  value = local.subnet_exists ? data.azurerm_subnet.subnet.0.address_prefixes : azurerm_subnet.subnet.0.address_prefixes
}
