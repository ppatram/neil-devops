variable "ecosystemId" {
  description = "Unique key for the instance of the environment"
  type        = string
  default     = ""
}

variable "aks_cluster_node_count" {
  description = "Azure AKS default node count"
  default     = 4
  type        = string
}

variable "aks_vm_size" {
  description = "Azure AKS VM Size"
  default     = "Standard_DS4_v2"
  type        = string
}

variable "aks_app_node_pool" {
  description = "AKS App Node Pool Count"
  type        = string
  default     = 0
}
