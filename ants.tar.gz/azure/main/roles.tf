data "azuread_group" "systems" {
  display_name     = "SystemsGroup"
  security_enabled = true
}

data "azuread_group" "k8s-contributor" {
  display_name     = "Azure - K8S - OG - Phoenix Dev Contributor"
  security_enabled = true
}

data "azuread_group" "k8s-cluster-admin" {
  display_name     = "Azure - K8S - OG - Phoenix Dev ClusterAdmin"
  security_enabled = true
}

resource "azurerm_role_assignment" "AKS_RBAC_SystemsGroup" {
  scope                = azurerm_kubernetes_cluster.app.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = data.azuread_group.systems.object_id
}

resource "azurerm_role_assignment" "AKS_RBAC_Cluster_Admin" {
  scope                = azurerm_kubernetes_cluster.app.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = data.azuread_group.k8s-cluster-admin.object_id
}

resource "azurerm_role_assignment" "AKS_RBAC_Admin" {
  scope                = azurerm_kubernetes_cluster.app.id
  role_definition_name = "Azure Kubernetes Service RBAC Admin"
  principal_id         = data.azuread_group.k8s-contributor.object_id
}
