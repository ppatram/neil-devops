resource "azurerm_servicebus_namespace" "app" {
  name                = format("%s-sbus", local.ecosystem_name)
  location            = data.azurerm_resource_group.app.location
  resource_group_name = data.azurerm_resource_group.app.name
  sku                 = "Standard"
  tags                = local.tags
  lifecycle {
    ignore_changes = [tags["CreatedOnDate"]]
  }
}

# resource "azurerm_private_endpoint" "sb" {
#   count               = azurerm_servicebus_namespace.app.sku == "Premium" ? 1 : 0
#   name                = format("%s-sb-pe", local.ecosystem_name)
#   location            = data.azurerm_resource_group.app.location
#   resource_group_name = data.azurerm_resource_group.app.name
#   subnet_id           = module.subnet_pe.subnet_id

#   private_dns_zone_group {
#     name                 = "private-dns-zone-group"
#     private_dns_zone_ids = [azurerm_private_dns_zone.sbus.id]
#   }

#   private_service_connection {
#     name                           = "tfex-ssa-connection"
#     is_manual_connection           = false
#     private_connection_resource_id = azurerm_servicebus_namespace.app.id
#     subresource_names              = ["namespace"]
#   }
#   tags = local.tags
#   lifecycle {
#     ignore_changes = [tags["CreatedOnDate"]]
#   }
# }
