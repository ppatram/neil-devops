data "tss_secret_name" "phoenixdb_rw" {
  path = "\\Phoenix\\phoenixdb_rw_dev"
}

data "tss_secret" "phoenixdb_rw" {
  field = "password"
  id    = data.tss_secret_name.phoenixdb_rw.value
}

data "tss_secret_name" "phoenixdb_ro" {
  path = "\\Phoenix\\phoenixdb-ro_dev"
}

data "tss_secret" "phoenixdb_ro" {
  field = "password"
  id    = data.tss_secret_name.phoenixdb_ro.value
}

data "tss_secret_name" "phoenixdb_dbo" {
  path = "\\Phoenix\\phoenixdb-dbo_dev"
}

data "tss_secret" "phoenixdb_dbo" {
  field = "password"
  id    = data.tss_secret_name.phoenixdb_dbo.value
}

data "tss_secret_name" "phoenixdb_dbt" {
  path = "\\Phoenix\\phoenixdb-dbt_dev"
}

data "tss_secret" "phoenixdb_dbt" {
  field = "password"
  id    = data.tss_secret_name.phoenixdb_dbt.value
}

data "tss_secret_name" "entra_client_secret" {
  path = "\\Phoenix\\entra-client-secret_dev"
}

data "tss_secret" "entra_client_secret" {
  field = "password"
  id    = data.tss_secret_name.entra_client_secret.value
}

data "tss_secret_name" "entra_reference_target" {
  path = "\\Phoenix\\entra-reference-target_dev"
}

data "tss_secret" "entra_reference_target" {
  field = "password"
  id    = data.tss_secret_name.entra_reference_target.value
}

data "tss_secret_name" "powerbi_client_secret" {
  path = "\\Phoenix\\powerbi-client-secret_dev"
}

data "tss_secret" "powerbi_client_secret" {
  field = "password"
  id    = data.tss_secret_name.powerbi_client_secret.value
}

data "tss_secret_name" "powerbi_workspace" {
  path = "\\Phoenix\\powerbi-workspace_dev"
}

data "tss_secret" "powerbi_workspace" {
  field = "password"
  id    = data.tss_secret_name.powerbi_workspace.value
}

data "tss_secret_name" "sftp_password" {
  path = "\\Phoenix\\sftp-password_dev"
}

data "tss_secret" "sftp_password" {
  field = "password"
  id    = data.tss_secret_name.sftp_password.value
}

data "tss_secret_name" "sharepoint_client_secret" {
  path = "\\Phoenix\\sharepoint-client-secret_dev"
}

data "tss_secret" "sharepoint_client_secret" {
  field = "password"
  id    = data.tss_secret_name.sharepoint_client_secret.value
}

data "tss_secret_name" "phoenixdb_serveradmin" {
  path = "\\Phoenix\\phoenixdb_dev_instance"
}

data "tss_secret" "phoenixdb_serveradmin_password" {
  field = "password"
  id    = data.tss_secret_name.phoenixdb_serveradmin.value
}

data "tss_secret" "phoenixdb_serveradmin_username" {
  field = "username"
  id    = data.tss_secret_name.phoenixdb_serveradmin.value
}

data "tss_secret_name" "azure_document_intelligence" {
  path = "\\Phoenix\\azure_document_intelligence"
}

data "tss_secret" "azure_document_intelligence" {
  field = "password"
  id    = data.tss_secret_name.azure_document_intelligence.value
}

data "tss_secret_name" "azure_openai_api_key" {
  path = "\\Phoenix\\azure_openai_api_key"
}

data "tss_secret" "azure_openai_api_key" {
  field = "password"
  id    = data.tss_secret_name.azure_openai_api_key.value
}

data "tss_secret_name" "zzPhoenixE2E" {
  path = "\\Phoenix\\E2E Test Suite Service Account for Phoenix"
}

data "tss_secret" "zzPhoenixE2E" {
  field = "password"
  id    = data.tss_secret_name.zzPhoenixE2E.value
}
