resource "azurerm_key_vault_secret" "azure_blob_storage" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "azure-blob-storage"
  value        = azurerm_storage_account.app.primary_connection_string
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "azure_service_bus" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "azure-service-bus"
  value        = azurerm_servicebus_namespace.app.default_primary_connection_string
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "kubeconfig" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "kubeconfig"
  value        = azurerm_kubernetes_cluster.app.kube_admin_config_raw
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "entra_client_secret" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "entra-client-secret"
  value        = data.tss_secret.entra_client_secret.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "phoenixdb_rw" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "phoenixdb-rw"
  value        = data.tss_secret.phoenixdb_rw.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "phoenixdb" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "phoenixdb"
  value        = "Server=tcp:${azurerm_mssql_server.app.fully_qualified_domain_name};Initial Catalog=${azurerm_mssql_database.serverless_db.name};Persist Security Info=False;User ID=phoenixdb_rw;Password='${data.tss_secret.phoenixdb_rw.value}';MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "phoenixdb_dbo" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "phoenixdb-dbo"
  value        = data.tss_secret.phoenixdb_dbo.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "phoenixdb_dbt" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "phoenixdb-dbt"
  value        = data.tss_secret.phoenixdb_dbt.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "phoenixdb_ro" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "phoenixdb-ro"
  value        = data.tss_secret.phoenixdb_ro.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "phoenixdb_serveradmin_username" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "phoenixdb-serveradmin-username"
  value        = data.tss_secret.phoenixdb_serveradmin_username.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "phoenixdb_serveradmin_password" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "phoenixdb-serveradmin-password"
  value        = data.tss_secret.phoenixdb_serveradmin_password.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "powerbi_client_secret" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "powerbi-client-secret"
  value        = data.tss_secret.powerbi_client_secret.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "powerbi_workspace" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "powerbi-workspace"
  value        = data.tss_secret.powerbi_workspace.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "sftp_password" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "sftp-password"
  value        = data.tss_secret.sftp_password.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "sharepoint_client_secret" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "sharepoint-client-secret"
  value        = data.tss_secret.sharepoint_client_secret.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "graph_client_secret" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "graph-client-secret"
  value        = "uND8Q~aD~YqHTaOWZs3WMckGR2WakwQnAo59Oa0S"
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "azure_document_intelligence" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "azure-document-intelligence"
  value        = data.tss_secret.azure_document_intelligence.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "azure_openai_api_key" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "azure-openai-api-key"
  value        = data.tss_secret.azure_openai_api_key.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "oriondb" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "oriondb"
  value        = "Data Source=STM-DWDEV-01.odysseyre.net;Initial Catalog=ORION;Uid=bouser;Password=barrie;"
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "fabric_client_secret" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "fabric-client-secret"
  value        = "uND8Q~aD~YqHTaOWZs3WMckGR2WakwQnAo59Oa0S"
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "zzPhoenixE2E" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "zzPhoenixE2E"
  value        = data.tss_secret.zzPhoenixE2E.value
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "aks_user_identity" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "aks-user-identity"
  value        = azurerm_kubernetes_cluster.app.key_vault_secrets_provider[0].secret_identity[0].client_id
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "public_apikey_metis" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "public-apikey-metis"
  value        = ""
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "public_apikey_actuarial_mx" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "public-apikey-actuarial-mx"
  value        = ""
  key_vault_id = azurerm_key_vault.app.id
}

resource "azurerm_key_vault_secret" "signalr_connection_string" {
  depends_on   = [azurerm_role_assignment.kva, ]
  name         = "signalr-connection-string"
  value        = ""
  key_vault_id = azurerm_key_vault.app.id
}
