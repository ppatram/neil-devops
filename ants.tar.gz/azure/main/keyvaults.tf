data "azurerm_client_config" "current" {
}

data "azurerm_key_vault" "devops_kv" {
  name                = "azeodyhdcogitdevops-kv"
  resource_group_name = "AZE-ODYHDC-OG-IT-DEVOPS-RG"
}

resource "azurerm_key_vault" "app" {
  name                        = format("%s-kv", local.ecosystem_name)
  location                    = data.azurerm_resource_group.app.location
  resource_group_name         = data.azurerm_resource_group.app.name
  enabled_for_disk_encryption = true
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  soft_delete_retention_days  = 30
  purge_protection_enabled    = false
  sku_name                    = "standard"
  enable_rbac_authorization   = true
  network_acls {
    default_action             = "Deny"
    bypass                     = "AzureServices"
    ip_rules                   = local.ody_public_nats
    virtual_network_subnet_ids = [
      data.azurerm_subnet.ody-core-private.id, 
      data.azurerm_subnet.vmss.id,
      module.subnet_aks.subnet_id
    ]
  }
  tags                        = local.tags
  lifecycle {
    ignore_changes = [tags["CreatedOnDate"]]
  }
}

resource "azurerm_role_assignment" "kva" {
  scope                = azurerm_key_vault.app.id
  role_definition_name = "Key Vault Administrator"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "kva_systems" {
  scope                = azurerm_key_vault.app.id
  role_definition_name = "Key Vault Administrator"
  principal_id         = data.azuread_group.systems.object_id
}

resource "azurerm_role_assignment" "kvr_phxdevs" {
  scope                = azurerm_key_vault.app.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = data.azuread_group.k8s-contributor.object_id
}

resource "azurerm_role_assignment" "kvr_csi_driver" {
  scope                = azurerm_key_vault.app.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_kubernetes_cluster.app.key_vault_secrets_provider[0].secret_identity[0].object_id
}

# resource "azurerm_private_endpoint" "kv" {
#   name                = format("%s-kv-pe", local.ecosystem_name)
#   location            = data.azurerm_resource_group.app.location
#   resource_group_name = data.azurerm_resource_group.app.name
#   subnet_id           = module.subnet_pe.subnet_id

#   private_dns_zone_group {
#     name                 = "private-dns-zone-group"
#     private_dns_zone_ids = [azurerm_private_dns_zone.keyvault.id]
#   }

#   private_service_connection {
#     name                           = "tfex-kv-connection"
#     is_manual_connection           = false
#     private_connection_resource_id = azurerm_key_vault.app.id
#     subresource_names              = ["vault"]
#   }
#   tags = local.tags
#   lifecycle {
#     ignore_changes = [tags["CreatedOnDate"]]
#   }
# }