data "azurerm_container_registry" "acr" {
  name                = "azeodyhdcogacr01"
  resource_group_name = "AZE-Services-ODYHDC-RG"
}

resource "azurerm_role_assignment" "kubernetes_to_acr" {
  scope                = data.azurerm_container_registry.acr.id
  role_definition_name = "AcrPull"
  principal_id         = azurerm_kubernetes_cluster.app.kubelet_identity[0].object_id
}