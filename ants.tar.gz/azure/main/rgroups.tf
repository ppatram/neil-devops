data "azurerm_resource_group" "app" {
  name = local.ecosystem_name
}
