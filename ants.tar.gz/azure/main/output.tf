output "rg" {
  value = data.azurerm_resource_group.app.name
}

output "aks_name" {
  value = azurerm_kubernetes_cluster.app.name
}

output "aks_cidr" {
  value = module.subnet_aks.subnet_cidr
}

output "pe_cidr" {
  value = module.subnet_pe.subnet_cidr
}

output "ecosystem_name" {
  value = local.ecosystem_name
}

output "ip" {
  value = data.azurerm_lb.internal.frontend_ip_configuration.0.private_ip_address
}

output "sql_ip" {
  value = azurerm_private_endpoint.sql.private_dns_zone_configs[0].record_sets[0].ip_addresses[0]
}

output "blob_ip" {
  value = azurerm_private_endpoint.blob.private_dns_zone_configs[0].record_sets[0].ip_addresses[0]
}

output "queue_ip" {
  value = azurerm_private_endpoint.queue.private_dns_zone_configs[0].record_sets[0].ip_addresses[0]
}

output "table_ip" {
  value = azurerm_private_endpoint.table.private_dns_zone_configs[0].record_sets[0].ip_addresses[0]
}
