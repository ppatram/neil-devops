data "azurerm_log_analytics_workspace" "og" {
  name                = "ody-default-la-workspace"
  resource_group_name = "aze-monitoring-rg"
}

resource "tls_private_key" "aksssh_pk" {
  algorithm = "RSA"
  rsa_bits  = 2048
}

resource "azurerm_key_vault_secret" "akssshkey_pk" {
  name         = format("%s-aks-sshpk", local.ecosystem_name)
  value        = tls_private_key.aksssh_pk.private_key_pem
  key_vault_id = data.azurerm_key_vault.devops_kv.id
}

resource "local_file" "aksssh_pub" {
  content  = tls_private_key.aksssh_pk.public_key_openssh
  filename = "${path.module}/aksssh.pub"
}

resource "azurerm_kubernetes_cluster" "app" {
  name                      = format("%s-aks", local.ecosystem_name)
  resource_group_name       = data.azurerm_resource_group.app.name
  node_resource_group       = format("%s-aks", data.azurerm_resource_group.app.name)
  dns_prefix                = format("%s-k8s", local.ecosystem_name)
  location                  = "eastus"
  kubernetes_version        = "1.35.1"
  automatic_upgrade_channel = "stable"
  azure_policy_enabled      = true
  oidc_issuer_enabled       = true

  linux_profile {
    admin_username = "ogad"
    ssh_key {
      key_data = tls_private_key.aksssh_pk.public_key_openssh
    }
  }

  default_node_pool {
    name                   = "system"
    type                   = "VirtualMachineScaleSets"
    auto_scaling_enabled   = true
    min_count              = var.aks_cluster_node_count
    max_count              = var.aks_cluster_node_count * 2
    max_pods               = 30
    vm_size                = var.aks_vm_size
    os_disk_size_gb        = 60
    vnet_subnet_id         = module.subnet_aks.subnet_id
    node_public_ip_enabled = false
    tags                   = local.tags
  }

  network_profile {
    load_balancer_sku = "standard"
    network_plugin    = "azure"
  }

  azure_active_directory_role_based_access_control {
    azure_rbac_enabled     = true
    admin_group_object_ids = tolist([data.azuread_group.systems.object_id])
  }

  identity {
    type = "SystemAssigned"
  }

  oms_agent {
    log_analytics_workspace_id = data.azurerm_log_analytics_workspace.og.id
  }

  key_vault_secrets_provider {
    secret_rotation_enabled  = true  # Enables automatic rotation
    secret_rotation_interval = "60m" # Frequency of rotation checks
  }

  tags = local.tags
  lifecycle {
    # TEMPORARY (remediation bridge): Container Insights (oms_agent) and
    # Managed Prometheus (monitor_metrics) are being enabled/repointed
    # out-of-band by scripts in docs/aks/rebuild/terraform-aks-logs/
    # (repoint-container-insights.sh, enable-prometheus.sh) toward dedicated
    # in-RG workspaces. Ignoring these prevents 'main' apply from reverting
    # those changes. REMOVE once the oms_agent / monitor_metrics blocks are
    # updated to the new workspaces and the remediation modules are merged.
    ignore_changes = [
      tags["CreatedOnDate"],
      oms_agent,
      monitor_metrics,
    ]
  }
  depends_on = [
    module.subnet_aks
  ]
}

resource "azurerm_kubernetes_cluster_node_pool" "app" {
  count                  = var.aks_app_node_pool
  name                   = format("app%02d", count.index)
  kubernetes_cluster_id  = azurerm_kubernetes_cluster.app.id
  vm_size                = var.aks_vm_size
  vnet_subnet_id         = module.subnet_aks.subnet_id
  node_count             = 3
  node_public_ip_enabled = false
  node_labels = {
    "application" = "Phoenix"
  }
  node_taints = [
    "app=true:NoSchedule"
  ]
  tags = local.tags
  lifecycle {
    ignore_changes = [tags["CreatedOnDate"]]
  }
}

resource "local_file" "kubeconfig_forhelm" {
  content  = azurerm_kubernetes_cluster.app.kube_admin_config_raw
  filename = "${path.module}/kubeconfig"
}

resource "local_file" "kubeconfig" {
  content  = azurerm_kubernetes_cluster.app.kube_admin_config_raw
  filename = "./kubeconfig"
}
