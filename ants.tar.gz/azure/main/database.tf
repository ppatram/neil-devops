data "template_file" "phoenixdb_dbo" {
  vars = {
    user_dbo = "phoenixdb_dbo"
    pwd_dbo  = azurerm_key_vault_secret.phoenixdb_dbo.value
    user_rw  = "phoenixdb_rw"
    pwd_rw   = azurerm_key_vault_secret.phoenixdb_rw.value
    user_dbt = "phoenixdb_dbt"
    pwd_dbt  = azurerm_key_vault_secret.phoenixdb_dbt.value

  }
  template = <<EOF
    if database_principal_id('$${user_dbo}') is null
    BEGIN 
      CREATE user [$${user_dbo}] with password='$${pwd_dbo}'
    END
    EXEC sp_addrolemember 'db_owner', '$${user_dbo}'

    if database_principal_id('$${user_rw}') is null
    BEGIN
      CREATE user [$${user_rw}] with password='$${pwd_rw}'
    END
    EXEC sp_addrolemember 'db_datareader', '$${user_rw}'
    EXEC sp_addrolemember 'db_datawriter', '$${user_rw}'

    if database_principal_id('$${user_dbt}') is null
    BEGIN 
      CREATE user [$${user_dbt}] with password='$${pwd_dbt}'
    END
    EXEC sp_addrolemember 'db_owner', '$${user_dbt}'
    EOF
}

resource "azurerm_mssql_server" "app" {
  name                = format("%s-sql", local.ecosystem_name)
  resource_group_name = data.azurerm_resource_group.app.name
  location            = data.azurerm_resource_group.app.location
  version             = "12.0"
  azuread_administrator {
    login_username = "AADPhoenixDevSQLAdmins"
    object_id      = "be70841e-097d-4ee3-add5-33052b45c08c"
    tenant_id      = "885e124e-4dc7-41ed-a268-3e401a62cead"
  }
  administrator_login          = azurerm_key_vault_secret.phoenixdb_serveradmin_username.value
  administrator_login_password = azurerm_key_vault_secret.phoenixdb_serveradmin_password.value
  public_network_access_enabled = false
  
  tags = local.tags
  lifecycle {
    ignore_changes = [tags["CreatedOnDate"]]
  }
}

resource "azurerm_mssql_database" "serverless_db" {
  name      = format("%s-sqldb", local.ecosystem_name)
  server_id = azurerm_mssql_server.app.id
  collation = "SQL_Latin1_General_CP1_CI_AS"

  auto_pause_delay_in_minutes = 60
  max_size_gb                 = 50
  min_capacity                = 0.5
  read_replica_count          = 0
  read_scale                  = false
  sku_name                    = "GP_S_Gen5_4"
  zone_redundant              = false

  threat_detection_policy {
    disabled_alerts      = []
    email_account_admins = "Disabled"
    email_addresses      = ["sbatter@odysseygroup.com"]
    retention_days       = 0
    state                = "Disabled"
  }
  tags = local.tags
  lifecycle {
    ignore_changes = [tags["CreatedOnDate"]]
  }
}

resource "local_sensitive_file" "phoenixdb_users" {
  depends_on = [azurerm_mssql_database.serverless_db]
  content    = data.template_file.phoenixdb_dbo.rendered
  filename   = "${path.module}/phoenixdb_users.sql"

  provisioner "local-exec" {
    command = "/opt/mssql-tools/bin/sqlcmd -S ${azurerm_private_endpoint.sql.private_dns_zone_configs[0].record_sets[0].ip_addresses[0]} -d ${azurerm_mssql_database.serverless_db.name} -U ${azurerm_key_vault_secret.phoenixdb_serveradmin_username.value}@${azurerm_mssql_server.app.fully_qualified_domain_name} -P '${azurerm_key_vault_secret.phoenixdb_serveradmin_password.value}' -i ${path.module}/phoenixdb_users.sql"
  }
}

# Create private endpoint for SQL server
resource "azurerm_private_endpoint" "sql" {
  name                = format("%s-sql-pe", local.ecosystem_name)
  resource_group_name = data.azurerm_resource_group.app.name
  location            = data.azurerm_resource_group.app.location
  subnet_id           = module.subnet_pe.subnet_id

  private_service_connection {
    name                           = "private-serviceconnection"
    private_connection_resource_id = azurerm_mssql_server.app.id
    subresource_names              = ["sqlServer"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "private-dns-zone-group"
    private_dns_zone_ids = [data.azurerm_private_dns_zone.sql_dns_zone.id]
  }
}

# Existing private DNS zone
data "azurerm_private_dns_zone" "sql_dns_zone" {
  name                = "privatelink.database.windows.net"
  resource_group_name = "aze-odyhdc-og-dns-privatelink-rg"
}
