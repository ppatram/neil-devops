terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.16.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 3.1.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.35.1"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.17.0"
    }
    tss = {
      source = "app.terraform.io/OdysseyGroup/tss"
      version = "1.0.7"
    }

  }
  required_version = ">= 1.2.0, < 2.0.0"
}

provider "azuread" {
  tenant_id       = local.tenant_id
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = false
    }
  }
  subscription_id                 = local.subscription_id
  tenant_id                       = local.tenant_id
  resource_provider_registrations = "none"
}

provider "azurerm" {
  features {}
  alias                           = "odysseyre"
  subscription_id                 = local.subscription_id
  tenant_id                       = local.tenant_id
  resource_provider_registrations = "none"
}

provider "azurerm" {
  features {}
  alias                           = "sub_odygrp_na_prod_01"
  subscription_id                 = "a83c988e-bad7-4d0f-ae50-199e0d83b942"
  tenant_id                       = local.tenant_id
  resource_provider_registrations = "none"
}

provider "kubernetes" {
  host                   = azurerm_kubernetes_cluster.app.kube_config.0.host
  client_certificate     = base64decode(azurerm_kubernetes_cluster.app.kube_admin_config.0.client_certificate)
  client_key             = base64decode(azurerm_kubernetes_cluster.app.kube_admin_config.0.client_key)
  cluster_ca_certificate = base64decode(azurerm_kubernetes_cluster.app.kube_admin_config.0.cluster_ca_certificate)
}

provider "helm" {
  kubernetes {
    host                   = azurerm_kubernetes_cluster.app.kube_config.0.host
    client_certificate     = base64decode(azurerm_kubernetes_cluster.app.kube_admin_config.0.client_certificate)
    client_key             = base64decode(azurerm_kubernetes_cluster.app.kube_admin_config.0.client_key)
    cluster_ca_certificate = base64decode(azurerm_kubernetes_cluster.app.kube_admin_config.0.cluster_ca_certificate)
  }
}

provider "tss" {
  username   = "ODYSSEYRE\\zzDevOps"
  server_url = "https://thycotic.odysseyre.net/SecretServer/"
}
