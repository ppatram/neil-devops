data "azurerm_key_vault_certificate_data" "httpcert" {
  name         = local.ecosystem_name
  key_vault_id = data.azurerm_key_vault.devops_kv.id
}

resource "kubernetes_namespace" "ingress" {
  metadata {
    annotations = {
      name = "ingress-nginx"
    }
    name = "ingress-nginx"
  }
}

resource "kubernetes_secret" "httpcert_app" {
  metadata {
    name      = "phoenix-ssl"
    namespace = "default"
  }
  data = {
    "tls.crt" = data.azurerm_key_vault_certificate_data.httpcert.pem
    "tls.key" = data.azurerm_key_vault_certificate_data.httpcert.key
  }
  type = "kubernetes.io/tls"
}

resource "azurerm_role_assignment" "aks_network_contributor" {
  scope                = data.azurerm_virtual_network.aks.id
  role_definition_name = "Network Contributor"
  principal_id         = azurerm_kubernetes_cluster.app.identity[0].principal_id
}

resource "helm_release" "ingress_nginxs" {
  depends_on = [
    kubernetes_namespace.ingress,
    kubernetes_secret.httpcert_app,
    azurerm_role_assignment.aks_network_contributor
  ]
  name            = "ingress-nginx-controller"
  namespace       = "ingress-nginx"
  repository      = "https://kubernetes.github.io/ingress-nginx"
  chart           = "ingress-nginx"
  force_update    = true
  cleanup_on_fail = true
  replace         = true
  timeout         = 3000

  set {
    name  = "controller.replicaCount"
    value = "3"
  }
  set {
    name  = "controller.defaultTLS.secret"
    value = "phoenix-ssl"
  }
  set {
    name  = "controller.watchIngressWithoutClass"
    value = "true"
  }
  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/azure-load-balancer-internal"
    value = "true"
  }
  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/azure-load-balancer-internal-subnet"
    value = local.ingress_vsnet
  }
  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/azure-load-balancer-health-probe-request-path"
    value = "/healthz"
  }
}

data "azurerm_lb" "internal" {
  depends_on = [
    helm_release.ingress_nginxs
  ]
  name                = "kubernetes-internal"
  resource_group_name = format("%s-aks", local.ecosystem_name)
}