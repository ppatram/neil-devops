data "azurerm_virtual_network" "aks" {
  name                = local.vnet_name
  resource_group_name = local.vnet_rg
}

data "azurerm_subnet" "aks_ingress" {
  name                 = local.ingress_vsnet
  virtual_network_name = local.vnet_name
  resource_group_name  = local.vnet_rg
}

data "azurerm_subnet" "ody-core-private" {
  provider             = azurerm.odysseyre
  name                 = "AZE-ODYHDC-Core-Private"
  virtual_network_name = "AZE-ODYHDC-VNET"
  resource_group_name  = "AZE-Network-ODYHDC-RG"
}

data "azurerm_subnet" "vmss" {
  provider             = azurerm.sub_odygrp_na_prod_01
  name                 = "snet-ado-agentpool-na-prod-01"
  virtual_network_name = "vnet-na-prod-odygrp-core-it-01"
  resource_group_name  = "rg-na-prod-odygrp-core-it-01"
}

module "subnet_pe" {
  source                                         = "./../modules/subnet"
  index                                          = 0
  vnet_name                                      = local.vnet_name
  vnet_rg                                        = local.vnet_rg
  subnet_name                                    = format("%s-pe-vsnet", local.ecosystem_name)
  private_endpoint_network_policies              = "Enabled"
  subnet_service_endpoints = [
    "Microsoft.KeyVault",
    "Microsoft.ServiceBus",
    "Microsoft.ContainerRegistry",
    "Microsoft.Sql",
    "Microsoft.Storage",
  ]
  tags = local.tags
}

module "subnet_aks" {
  source                                         = "./../modules/subnet"
  index                                          = 1
  vnet_name                                      = local.vnet_name
  vnet_rg                                        = local.vnet_rg
  subnet_name                                    = format("%s-aks-vsnet", local.ecosystem_name)
  private_endpoint_network_policies              = "Disabled"
  subnet_service_endpoints = [
    "Microsoft.KeyVault",
    "Microsoft.ServiceBus",
    "Microsoft.ContainerRegistry",
    "Microsoft.Sql",
    "Microsoft.Storage",
  ]
  tags = local.tags
}

# ----------------------------------------------
# Workaround for tunnelfront connectivity issue - port 9000 blocked
# ----------------------------------------------

# data "dns_a_record_set" "aks_api" {
#   host = azurerm_kubernetes_cluster.app.fqdn
# }

# resource "azurerm_route_table" "aks" {
#   name                          = lower(format("%s-rt", local.ecosystem_name))
#   location                      = data.azurerm_resource_group.app.location
#   resource_group_name           = data.azurerm_resource_group.app.name
#   disable_bgp_route_propagation = false

#   route {
#     name           = "api"
#     address_prefix = format("%s/32", data.dns_a_record_set.aks_api.addrs.0)
#     next_hop_type  = "Internet"
#   }

#   tags = local.tags
#   lifecycle {
#     ignore_changes = [tags["CreatedOnDate"]]
#   }
# }

# resource "azurerm_subnet_route_table_association" "aks" {
#   subnet_id      = module.subnet_aks.subnet_id
#   route_table_id = azurerm_route_table.aks.id
# }
