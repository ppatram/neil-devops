resource "azurerm_storage_account" "app" {
  name                          = format("%ssa", replace(lower(local.ecosystem_name), "-", ""))
  resource_group_name           = data.azurerm_resource_group.app.name
  location                      = data.azurerm_resource_group.app.location
  account_tier                  = "Standard"
  account_replication_type      = "LRS"
  public_network_access_enabled = false
  tags                          = local.tags
  lifecycle {
    ignore_changes = [tags["CreatedOnDate"]]
  }
}

# Create private endpoint for blob storage
resource "azurerm_private_endpoint" "blob" {
  name                = format("%s-ssa-blob-pe", local.ecosystem_name)
  resource_group_name = data.azurerm_resource_group.app.name
  location            = data.azurerm_resource_group.app.location
  subnet_id           = module.subnet_pe.subnet_id

  private_service_connection {
    name                           = "private-serviceconnection-blob"
    private_connection_resource_id = azurerm_storage_account.app.id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "private-dns-zone-group"
    private_dns_zone_ids = [data.azurerm_private_dns_zone.blob_dns_zone.id]
  }
}

data "azurerm_private_dns_zone" "blob_dns_zone" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = "aze-odyhdc-og-dns-privatelink-rg"
}


# Create private endpoint for queue storage
resource "azurerm_private_endpoint" "queue" {
  name                = format("%s-ssa-queue-pe", local.ecosystem_name)
  resource_group_name = data.azurerm_resource_group.app.name
  location            = data.azurerm_resource_group.app.location
  subnet_id           = module.subnet_pe.subnet_id

  private_service_connection {
    name                           = "private-serviceconnection-queue"
    private_connection_resource_id = azurerm_storage_account.app.id
    subresource_names              = ["queue"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "private-dns-zone-group"
    private_dns_zone_ids = [data.azurerm_private_dns_zone.queue_dns_zone.id]
  }
}

data "azurerm_private_dns_zone" "queue_dns_zone" {
  name                = "privatelink.queue.core.windows.net"
  resource_group_name = "aze-odyhdc-og-dns-privatelink-rg"
}


# Create private endpoint for table storage
resource "azurerm_private_endpoint" "table" {
  name                = format("%s-ssa-table-pe", local.ecosystem_name)
  resource_group_name = data.azurerm_resource_group.app.name
  location            = data.azurerm_resource_group.app.location
  subnet_id           = module.subnet_pe.subnet_id

  private_service_connection {
    name                           = "private-serviceconnection-table"
    private_connection_resource_id = azurerm_storage_account.app.id
    subresource_names              = ["table"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "private-dns-zone-group"
    private_dns_zone_ids = [data.azurerm_private_dns_zone.table_dns_zone.id]
  }
}

data "azurerm_private_dns_zone" "table_dns_zone" {
  name                = "privatelink.table.core.windows.net"
  resource_group_name = "aze-odyhdc-og-dns-privatelink-rg"
}


