locals {
  ecosystem_name  = format("phoenix-%s", var.ecosystemId)
  subscription_id = "3e56c6ff-0d38-4f6a-9d6e-2c40efe46126"
  tenant_id       = "885e124e-4dc7-41ed-a268-3e401a62cead"
  vnet_name       = "AZE-ODYHDC-K8S-NP-VNET"
  vnet_rg         = "AZE-ODYHDC-OG-NonProd-RG"
  ingress_vsnet   = "AZE-ODYHDC-OG-K8S-NP-Entry"
  ody_public_nats                 = ["13.90.210.180/32", "13.92.227.141/32", "23.96.109.224/32", "31.221.25.163/32", "40.112.51.118/32", "40.117.141.227/32", "40.71.11.137/32", "40.71.42.249/32", "47.19.109.241/32", "47.19.109.253/32", "64.47.143.246/32", "64.47.232.217/32", "69.176.101.131/32", "69.176.101.194/32", "104.211.48.73/32", "168.62.165.241/32", "168.62.182.40/32", "208.215.188.241/32", "208.215.188.241/32"]
  authorized_ip_ranges            =  local.ody_public_nats
  api_server_authorized_ip_ranges =  local.ody_public_nats

  tags = {
    Environment  = "DEV"
    Company      = "OdysseyRe"
    Application  = "Phoenix"
    Organization = "OdysseyGroup"
    AppFamily    = "Phoenix"
  }
}
