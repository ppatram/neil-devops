# Phoenix Main Terraform
Provisions a new ecosystem of resources to be able to run the Phoenix application, including:

### AKS

### SQL Database

### Service Bus

### Key Vault

### Storage Account

### Subnets

